import math
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from datetime import datetime, date
plt.style.use('ggplot')

# Cleaning Customer Address
# Loading the data from excel file
clean_address = pd.read_excel(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Raw_data.xlsx', sheet_name='CustomerAddress')

# Display the total records and columns
print("Total records: {}".format(clean_address.shape[0]))
print("Total columns: {}".format(clean_address.shape[1]))

# select numeric columns
df_numeric = clean_address.select_dtypes(include=[np.number])
numeric_cols = df_numeric.columns.values
print("The numeric columns: {}".format(numeric_cols))

# select non-numeric columns
df_non_numeric = clean_address.select_dtypes(exclude=[np.number])
non_numerics_cols = df_non_numeric.columns.values
print("The non-numeric columns: {}".format(non_numerics_cols))

# Checking missing values
print(clean_address.isna().sum())

# Repalce the full state names into short forms
def replace_state_names(state_name):
    if state_name=='New South Wales':
        return 'NSW'
    elif state_name=="Victoria":
        return 'VIC'
    else:
        return state_name
# Apply the function
clean_address['state'] = clean_address['state'].apply(replace_state_names)

# Checking state
print(clean_address['state'].value_counts())

# Checking the country
print(clean_address['country'].value_counts())

# Checking postcode
clean_address[['address','postcode','state','country']].drop_duplicates()

# Duplication check
# Dropping the primary key(customer_id) and store into a temporary dataframe
clean_address_dedupped = clean_address.drop('customer_id', axis=1).drop_duplicates()

print("Number of records after removing customer_id (pk), duplicates : {}".format(clean_address_dedupped.shape[0]))
print("Number of records in original dataset : {}".format(clean_address.shape[0]))

# Export the cleaned data into csv file
clean_address.to_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_CustomerAddress.csv', index=False)

# ---------------------------------------------------------------------------------------------------------

# Cleaning Customer Demographic
# Loading the data
clean_demographic = pd.read_excel(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Raw_data.xlsx', sheet_name='CustomerDemographic')

print(clean_demographic.info())

# Print total records and rows
print("Total record: {}".format(clean_demographic.shape[0]))
print("Total row: {}".format(clean_demographic.shape[1]))

# select numeric columns
df_numeric = clean_demographic.select_dtypes(include=[np.number])
numeric_cols = df_numeric.columns.values
print("the numeric columns: {}".format(numeric_cols))

# select non-numeric columns
df_non_numeric = clean_demographic.select_dtypes(exclude=[np.number])
non_numeric_cols = df_non_numeric.columns.values
print("The non-numeric columns: {}".format(non_numeric_cols))

# Dropping Irrelevent columns (default columns)
clean_demographic.drop(labels={'default'}, axis=1, inplace=True)

# Checking missing values
print(clean_demographic.isna().sum())

# Percentage of missing values
print(clean_demographic.isnull().mean()*100)

# Checking for the percentage of first name and customer id in records where last name is missing
print(clean_demographic[clean_demographic['last_name'].isna()][['first_name', 'customer_id']].isnull().sum())

# Filling 'None' in last name
clean_demographic['last_name'].fillna('None', axis=0, inplace=True)

# checking last name missing values (It should be 0)
print(clean_demographic['last_name'].isna().sum())

# Checking DOB missing values
print(clean_demographic[clean_demographic['DOB'].isna()])

# Round the number to two decimal
print(round(clean_demographic['DOB'].isnull().mean()*100))

# The output is less than 5%, remove the records where date of birth is null
dob_index_drop = clean_demographic[clean_demographic['DOB'].isna()].index
print(dob_index_drop)

clean_demographic.drop(index=dob_index_drop, inplace=True, axis=0)
print(clean_demographic['DOB'].isnull().sum())

# Creating Age Column for checking futher descripency in data
# Calculate the age as of today based on the DOB 
def age(born_str):
    born = pd.to_datetime(born_str)
    today = date.today()

    return today.year - born.year - ((today.month,today.day) < (born.month, born.day))

clean_demographic['Age'] = clean_demographic['DOB'].apply(age)

# plot to find out the Age Distribution
plt.figure(figsize=(20, 8))
sns.histplot(clean_demographic['Age'], kde=False, bins=50)
plt.show()

print(clean_demographic['Age'].describe())

# Check who is older than 100 years old (Outlier)
print(clean_demographic[clean_demographic['Age'] > 100])

# remove an outlier
age_index_drop = clean_demographic[clean_demographic['Age'] > 100].index
clean_demographic.drop(index=age_index_drop, axis=0, inplace=True )

# Checking the missing value of Tenure
print(clean_demographic['tenure'].isnull().sum())

# Checking the missing value of Job title
print(clean_demographic[clean_demographic['job_title'].isnull()]) 

# Replace missing value with 'Missing'
clean_demographic['job_title'].fillna('Missing', inplace=True, axis=0)
print(clean_demographic['job_title'].isnull().sum())

# Checking the missing values of Job Industry Category
print(clean_demographic['job_industry_category'].isnull().sum())

# replace missing value of Job Industry Category
clean_demographic['job_industry_category'].fillna('Missing',inplace=True, axis=0)
print(clean_demographic['job_industry_category'].isnull().sum())

# Check the missing values in the dataset
print(clean_demographic.isnull().sum())

# The total records after remove Missing value
print("Total records after removing Missing values: {}".format(clean_demographic.shape[0]))

#  Inconsistency Checking gender
print(clean_demographic['gender'].value_counts())

# Replace the short forms into the full gender
def replace_gender_names(gender):
    if gender=='F':
        return 'Female'
    elif gender=='Femal':
        return 'Female'
    elif gender== 'M':
        return 'Male'
    else:
        return gender

# Apply the function
clean_demographic['gender'] = clean_demographic['gender'].apply(replace_gender_names)

#  Inconsistency Checking gender after applied the function
print(clean_demographic['gender'].value_counts())

# Wealth Segment
print(clean_demographic['wealth_segment'].value_counts())

# Deceased Indicator
print(clean_demographic['deceased_indicator'].value_counts())

# Owns car
print(clean_demographic['owns_car'].value_counts())

# Duplicate check
clean_demo_dedupped = clean_demographic.drop('customer_id', axis=1).drop_duplicates()

print("Number of records after removing customer_id (pk), duplicates: {}".format(clean_demo_dedupped.shape[0]))
print("Number of records in original dateset: {}".format(clean_demographic.shape[0]))

# Export the cleaned data to csv file
clean_demographic.to_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_CustomerDemographic.csv',index=False)
# -------------------------------------------------------------------------------------------------

# Cleaning New Customer list
clean_new = pd.read_excel(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Raw_data.xlsx', sheet_name='NewCustomerList')

print(clean_new.head(5))
print(clean_new.info())

print("Total record: {}".format(clean_new.shape[0]))
print("Total row: {}".format(clean_new.shape[1]))

# Select numeric columns
df_numeric = clean_new.select_dtypes(include=[np.number])
numeric_cols = df_numeric.columns.values
print("The numeric columns: {}".format(numeric_cols))

# Select non-numeric columns
df_non_numeric = clean_new.select_dtypes(exclude=[np.number])
non_numeric_cols = df_non_numeric.columns.values
print("The non-numeric columns: {}".format(non_numeric_cols))

# Drop Irrelevent values
clean_new.drop(labels=['Unnamed: 16','Unnamed: 17','Unnamed: 18','Unnamed: 19','Unnamed: 20'], axis=1, inplace=True)

# Total missing values
print(clean_new.isnull().sum())
print(clean_new.isnull().mean()*100)

# Last name
print(clean_new[clean_new['last_name'].isna()][['first_name']].isnull().sum())
print(clean_new[clean_new['last_name'].isnull()])

clean_new['last_name'].fillna('None',axis=0, inplace=True)
print(clean_new['last_name'].isna().sum())

# DOB
print(clean_new['DOB'].isnull().sum())
print(clean_new['DOB'].isnull().mean()*100)

dob_index_drop = clean_new[clean_new['DOB'].isna()].index
print(dob_index_drop)

clean_new.drop(labels=dob_index_drop,axis=0, inplace=True)
print(clean_new['DOB'].isna().sum())

# Creating Age column for checking further descripency in data
def age(born_str):
    born = pd.to_datetime(born_str)
    today = date.today()

    return today.year - born.year - ((today.month,today.day) < (born.month,born.day))
clean_new['Age'] = clean_new['DOB'].apply(age)

print(clean_new['Age'].describe())

# plot to find out the age distribution
plt.figure(figsize=(15,8))
sns.histplot(clean_new['Age'], kde=False, bins=50)
plt.show()

# Creating age group column
clean_new['Age Group'] = clean_new['Age'].apply(lambda x : (math.floor(x/10)+1)*10)

# Viz to find out the Age Group Distribution
plt.figure(figsize=(10,8))
sns.histplot(clean_new['Age Group'], kde=False, bins=50)

# Job Title
print(clean_new[clean_new['job_title'].isnull()])

clean_new['job_title'].fillna('Missing', axis=0, inplace=True)
print(clean_new['job_title'].isnull().sum())

# Job industry category
print(clean_new['job_industry_category'].isnull().sum())

clean_new['job_industry_category'].fillna('Missing', axis=0, inplace=True)
print(clean_new['job_industry_category'].isnull().sum())

# Checking missing values
print(clean_new.isnull().sum())

print('Total records after removing missing values: {}'.format(clean_new.shape[0]))
# # Inconsistency Check in Data
print(clean_new['gender'].value_counts())
print(clean_new['wealth_segment'].value_counts())
print(clean_new['deceased_indicator'].value_counts())
print(clean_new['owns_car'].value_counts())
print(clean_new['state'].value_counts())
print(clean_new['country'].value_counts())
print(clean_new[['postcode','state']].drop_duplicates().sort_values('state'))
print(clean_new[['address','postcode','state','country']].sort_values('address'))
print(clean_new['tenure'].describe())

# Distribution of tenure
plt.figure(figsize=(15,8))
sns.histplot(clean_new['tenure'])
plt.show()

# Duplicate checks
clean_new_dedupped = clean_new.drop_duplicates()

print('Number of records after removing customer_id(pk), duplicates: {}'.format(clean_new_dedupped.shape[0]))
print("Number of records in original dataset: {}".format(clean_new.shape[0]))

# Export the cleaned data to csv file
clean_new.to_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_NewCustomerList.csv',index=False)
# -----------------------------------------------------------------------------------------------------

# Cleaning Transactions
clean_trans = pd.read_excel(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Raw_data.xlsx', sheet_name='Transactions')

print(clean_trans.head(5))
print(clean_trans.info())

print("Total records: {}".format(clean_trans.shape[0]))
print("Total rows: {}".format(clean_trans.shape[1]))

# Select numeric columns
df_numeric = clean_trans.select_dtypes(include=[np.number])
numeric_cols = df_numeric.columns.values
print("The numeric columns: {}".format(numeric_cols))

# Select non-numeric columns
df_non_numeric = clean_trans.select_dtypes(exclude=[np.number])
non_numeric_cols = df_non_numeric.columns.values
print("The non numeric columns: {}".format(non_numeric_cols))

# Checking missing values
print(clean_trans.isnull().sum())
print(clean_trans.isnull().mean()*100)

# Online order
print(clean_trans[clean_trans['online_order'].isnull()])
most_freq_online_mode = clean_trans['online_order'].mode()
print(most_freq_online_mode)

clean_trans['online_order'].fillna(1, inplace=True)
print(clean_trans['online_order'].isnull().sum())

# Drop duplicate brand, product line, product class, product size, standard cost, product first sold date
clean_trans[clean_trans['brand'].isnull()][['brand','product_line','product_class','product_size',
                                            'standard_cost','product_first_sold_date']].drop_duplicates()

print(clean_trans[clean_trans['brand'].isnull()][['brand','product_line','product_class','product_size',
                                            'standard_cost','product_first_sold_date']].shape[0])

records_to_drop = clean_trans[clean_trans['brand'].isnull()][['brand','product_line','product_class','product_size',
                                            'standard_cost','product_first_sold_date']].index
print(records_to_drop)

clean_trans.drop(index=records_to_drop, axis=0, inplace=True)

print(clean_trans.isnull().sum())

print("Total records after removing Missing Values: {}".format(clean_trans.shape[0]))

# Creat a new feature "Profit"
clean_trans['Profit'] = clean_trans['list_price'] - clean_trans['standard_cost']

# Dystribution of the Profit Column
plt.figure(figsize=(20,8))
sns.histplot(clean_trans['Profit'])
plt.show()

# Inconsistency Check in Data

print(clean_trans['online_order'].value_counts())
print(clean_trans['order_status'].value_counts())
print(clean_trans[['order_status','online_order']].drop_duplicates())
print(clean_trans['product_line'].value_counts())
print(clean_trans['product_class'].value_counts())
print(clean_trans['product_size'].value_counts())
print(clean_trans['brand'].value_counts())

# Duplication Checks
# Dropping the primary key(transaction_id)
clean_trans_dedupped = clean_trans.drop('transaction_id',axis=1).drop_duplicates()

print("Number of records after removing transaction_id (pk), duplicates: {}".format(clean_trans_dedupped.shape[0]))
print("Number of records in original dataset: {}".format(clean_trans.shape[0]))


# Export the cleaned data into csv file
clean_trans.to_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_Transaction.csv', index=False)
