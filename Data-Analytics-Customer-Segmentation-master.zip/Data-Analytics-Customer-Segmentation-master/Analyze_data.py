import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import seaborn as sns

from datetime import datetime, date
plt.style.use('ggplot')

# Loading the Transactions and Customer Demographics Datasets

trans = pd.read_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_Transaction.csv')
cust = pd.read_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_CustomerDemographic.csv')

print(trans.head(5))

print("Totoal records in the Transaction dataset: {}".format(trans.shape[0]))
print("Total features (columns) in the Transaction Dataset: {}".format(trans.shape[1]))

print(cust.head(5))

print("Total records in the Customer Demographic Dataset: {}".format(cust.shape[0]))
print("Total features (columns) in Customer Demographic dataset: {}".format(cust.shape[1]))

# Merging both Transaction and Customer Demographic based on customer_id
merged_trans_cust = pd.merge(trans,cust, left_on='customer_id',right_on='customer_id', how='inner')

print(merged_trans_cust.head(5))

print("Total records in the Merged Dataset: {}".format(merged_trans_cust.shape[0]))
print("Total features (columns) in Merged Dataset: {}".format(merged_trans_cust.shape[1]))

print(merged_trans_cust.info())

# Hence the data type of the column should be changed from object to datetime type
merged_trans_cust['transaction_date']= pd.to_datetime(merged_trans_cust['transaction_date'])

# RFM Analysis
# Maximum Transaction Date or the latest transaction date.
max_trans_date = max(merged_trans_cust['transaction_date']).date()
print(max_trans_date)

# Taking the last transaction date as a reference date for comparision and
# finding the number of days between a transaction date and last transaction date to compute the recency
comparision_date = datetime.strptime(str(max_trans_date), "%Y-%m-%d")

# Creating a RFM table that will contain all the values for recency, frequency, and Monetray data.
rfm_table = merged_trans_cust.groupby(['customer_id']).agg({'transaction_date': lambda date : (comparision_date - date.max()).days,
                                                            'product_id': lambda prod_id : len(prod_id),
                                                            'Profit' : lambda p : sum(p)})

print(rfm_table.columns)

# Renaming column names to appropiate names
rfm_table.rename(columns={'transaction_date' : 'recency',
                          'product_id' : 'frequency',
                          'Profit' : 'monetary'}, inplace=True)

# Dividing the recency, frequency and monetary into 4 quartiles (min, 25%, 50%, 75%, and max)
# These values will help us to calculate RFM score for a customer and classify based on their RFM score.
rfm_table['r_quartile'] = pd.qcut(rfm_table["recency"], 4, ['4','3','2','1'])
rfm_table['f_quartile'] = pd.qcut(rfm_table['frequency'], 4, ['1','2','3','4'])
rfm_table['m_quartile']= pd.qcut(rfm_table['monetary'], 4, ['1','2','3','4'])

print(rfm_table)

# Calculate RFM Score
# Max weightage is given to recency then frequency and then monetary
rfm_table['rfm_score']= 100*rfm_table['r_quartile'].astype(int)+10*rfm_table['f_quartile'].astype(int)+rfm_table['r_quartile'].astype(int)

# Assigning a title to a customer.
# Platinum corresponds to highest range of RFM score down to Bronze to lowest range of RFM score.
rfm_table['customer_class'] = pd.qcut(rfm_table['rfm_score'], 4,['Bronze','Silver','Gold','Platinum'])
print(rfm_table)

# Merging both RFM Table with Transaction and Customer Tables
cust_trans_rfm = pd.merge(merged_trans_cust,rfm_table,left_on='customer_id',right_on='customer_id',how='inner')

print(cust_trans_rfm.info())

# Creating an Age Group Feature(Column)
cust_trans_rfm['Age_Group'] = cust_trans_rfm['Age'].apply(lambda x : (math.floor(x/10)+1)*10)

# Creating a detail customer class / tag based on RFM Score
# Function as a lookup to appropiate customer titles based on RFM score
def cust_score_title_lkup(cols):
    rfm_score = cols[0]
    if rfm_score >= 444:
        return "Platinum Customer"
    elif rfm_score >= 443 and rfm_score < 444:
        return "Very Loyal"
    elif rfm_score >= 421 and rfm_score < 443:
        return "Becoming Loyal"
    elif rfm_score >= 344 and rfm_score < 421:
        return "Recent Customer"
    elif rfm_score >= 323 and rfm_score < 344:
        return "Potential Customer"
    elif rfm_score >= 311 and rfm_score < 323:
        return "Late Bloomer"
    elif rfm_score >= 224 and rfm_score < 311:
        return "Loosing Customer"
    elif rfm_score >= 212 and rfm_score < 224:
        return "High Risk Customer"
    elif rfm_score >= 124 and rfm_score < 212:
        return "Almost Lost Customer"
    elif rfm_score >= 112 and rfm_score < 124:
        return "Evasive Customer"
    else : 
        return "Lost Customer"

# Applying the above functions and creating a new feature detail_cust_title
cust_trans_rfm['detail_cust_title']=cust_trans_rfm[['rfm_score']].apply(cust_score_title_lkup, axis=1)

# Function to provide ranks to the customers based on their title
def get_rank(cols):

    title = cols[0]

    if title=="Platinum Customer":
        return 1
    elif title=="Very Loyal":
        return 2
    elif title=="Becoming Loyal":
        return 3
    elif title=="Recent Coustomer":
        return 4
    elif title=="Potential Customer":
        return 5
    elif title=="Late Bloomer":
        return 6
    elif title=="Loosing Customer":
        return 7
    elif title=="High Risk Customer":
        return 8
    elif title=="Almost Lost Customer":
        return 9
    elif title=="Evasive Customer":
        return 10
    else :
        return 11

# Applying the above functions and creating a new feature rank
cust_trans_rfm["rank"]=cust_trans_rfm[['detail_cust_title']].apply(get_rank, axis=1)

# Exporting to CSV file
# cust_trans_rfm.to_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Customer_Trans_RFM.csv', index=False)

print("Total records in final dataset : {}".format(cust_trans_rfm.shape[0]))

# 3. Data Analysis and Exploration
# 3.1 New Customer vs Old Customer Age Distributions

# Loading the New Customer Dataset

new_cust = pd.read_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_NewCustomerList.csv')

# New Customer
plt.figure(figsize=(10,8))
sns.histplot(new_cust['Age Group'], kde=False, bins=15)
plt.xlabel('Age Group')
plt.ylabel('Number of Customers')
plt.title('New Customers - Age Distribution')
plt.show()

# Old Customer
plt.figure(figsize=(10,8))
sns.histplot(cust_trans_rfm['Age_Group'], kde=False, bins=15)
plt.xlabel('Age Group')
plt.ylabel("Number of Customer")
plt.title("Old Customer - Age Distribution")
plt.show()

# 3.2 Bike related purchases over last 3 years by gender
# Over the last 3 years around 51% of buyers are women and 49% are men
cust_bike_purchase_by_gender = cust_trans_rfm.groupby('gender').agg({'past_3_years_bike_related_purchases' : sum}
                                                                    ).reset_index() 

total_records = cust_trans_rfm['past_3_years_bike_related_purchases'].sum()

cust_bike_purchase_by_gender['Percent_of_total'] = (cust_bike_purchase_by_gender['past_3_years_bike_related_purchases']
                                                    /total_records)*100

print(cust_bike_purchase_by_gender)

plt.figure(figsize=(8,5))
sns.barplot(data=cust_bike_purchase_by_gender, x='gender', y='Percent_of_total')
plt.xlabel('Gender')
plt.ylabel('Percent of Total Purchases')
plt.title('Female vs Male past 3 years Bike purchases')
plt.show()

# 3.3 Job Industry Customer Distribution
# New Customers
plt.figure(figsize=(15,8))
sns.countplot(x='job_industry_category', data=new_cust[~(new_cust['job_industry_category']=='Misiing')])
plt.xlabel('Job Industry')
plt.ylabel('Number of Customers')
plt.title("New Customers - Job Industry Customer Distribution")
plt.show()

# Old Customers
plt.figure(figsize=(15,8))
sns.countplot(x="job_industry_category", data=cust_trans_rfm[~(cust_trans_rfm['job_industry_category']=='Misiing')])
plt.xlabel('Job Industry')
plt.ylabel('Number of Customers')
plt.title("Old Customers - Job Industry Customer Distribution")
plt.show()

# 3.4 Wealth Segmentation by Age Group
wealth_age_seg_new = new_cust.groupby(['wealth_segment','Age Group']).size().reset_index()

wealth_age_seg_new.rename(columns={0:'Number of Customers'},inplace=True)
print(wealth_age_seg_new)

plt.figure(figsize=(15,8))
sns.barplot(x="Age Group", y='Number of Customers', data=wealth_age_seg_new, hue='wealth_segment')
plt.xlabel('Age Group')
plt.ylabel('Nummber of Customers')
plt.title('New Customer - Wealth Segmentation by Age Group')
plt.show()

# Old Customers
wealth_age_seg_old = cust_trans_rfm.groupby(['wealth_segment','Age_Group']).size().reset_index()

wealth_age_seg_old.rename(columns={0:'Number of Customers'}, inplace=True)
print(wealth_age_seg_old)

plt.figure(figsize=(15,8))
sns.barplot(x='Age_Group', y='Number of Customers', data=wealth_age_seg_old, hue= "wealth_segment")
plt.xlabel('Age Group')
plt.ylabel('Number 0f Customers')
plt.title('Old Customer - Wealth Segmentation by Age Group')
plt.show()

# 3.5 Car owner across each State
# Loading The Customer Address
cust_addr_info = pd.read_csv(r'C:\Users\Nutda\OneDrive\Desktop\BI & Data Analysis\Customer-Segmentation\Data-Analytics-Customer-Segmentation-master\Cleaned_CustomerAddress.csv')

# Merging the RFM data with Customer Address Datast
cust_trans_addr = pd.merge(cust_trans_rfm,cust_addr_info, left_on='customer_id', 
                           right_on='customer_id', how='inner')

print("RFM table Records count : {}\nAddress Tble Records count: {}".format(cust_trans_rfm.shape[0] ,cust_addr_info.shape[0]))

# State car owner
state_car_owners = cust_trans_addr[['state','owns_car','customer_id']].drop_duplicates().groupby(['state','owns_car']).size().reset_index()

state_car_owners.rename(columns={0:'Number of Customers'}, inplace=True)
print(state_car_owners)

plt.figure(figsize=(8,7))
sns.barplot(data=state_car_owners, x='state',y='Number of Customers',hue='owns_car')
plt.ylabel('Number of Customers')
plt.xlabel('States')
plt.title('Number of Customer who onws a car')
plt.show()

# 4. RFM Analysis Scatter Plot
# 4.1 Recency vs Monetary
plt.figure(figsize=(8,7))
cust_trans_rfm.plot.scatter(x='recency', y='monetary')
plt.xlabel('Recency')
plt.ylabel('Monetary  ($)')
plt.title('Recency vs Monetary')
plt.show()

# 4.2 Frequency vs Monetary
plt.figure(figsize=(8,7))
cust_trans_rfm.plot.scatter(x='frequency', y='monetary')
plt.xlabel('Frequency')
plt.ylabel('Monetary ($)')
plt.title('Frequency vs Monetary')
plt.show()

# 5. Customer Segment Distribution
# Plot the number of customers present under a Customer Segment
# Calculating the number of unique customers under a customer title
cust_per_title = cust_trans_rfm[['detail_cust_title','customer_id','rank']].drop_duplicates().groupby(
    ['detail_cust_title','rank']).size().reset_index().sort_values('rank')

cust_per_title.rename(columns={0:'Number of Customers'}, inplace=True)
print(cust_per_title)

# Plotting the Number of Customers
plt.figure(figsize=(15,8))
sns.barplot(y='detail_cust_title',x='Number of Customers', data=cust_per_title)
plt.xlabel('Number of Customers')
plt.ylabel('Customer Segment')
plt.title('Number of Customers by Customer Segment')
plt.show()

